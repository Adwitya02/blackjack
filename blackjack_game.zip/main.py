from game import BlackjackGame

if __name__ == "__main__":
    name = input("Enter your name: ").strip()
    while True:
        game = BlackjackGame(name)
        game.start()
        again = input("Play again? (Y/N): ").strip().lower()
        if again != 'y':
            print("Thanks for playing!")
            break
