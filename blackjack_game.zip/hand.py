class Hand:
    def __init__(self):
        self.cards = []

    def add_card(self, card):
        self.cards.append(card)

    def calculate_value(self):
        total = 0
        aces = 0
        for card in self.cards:
            total += card.value()
            if card.rank == 'Ace':
                aces += 1
        while total > 21 and aces:
            total -= 10
            aces -= 1
        return total

    def display(self, owner):
        print(f"{owner}'s cards:")
        for card in self.cards:
            print(f"  {card}")
        print()
