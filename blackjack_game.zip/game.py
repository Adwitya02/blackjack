from deck import Deck
from hand import Hand

class BlackjackGame:
    def __init__(self, player_name):
        self.player_name = player_name
        self.deck = Deck()
        self.player_hand = Hand()
        self.dealer_hand = Hand()

    def start(self):
        print(f"\nHi {self.player_name}, welcome to Blackjack!\n")
        self.player_hand = Hand()
        self.dealer_hand = Hand()
        self.deck = Deck()
        self.deal_initial_cards()
        self.player_turn()
        if self.player_hand.calculate_value() <= 21:
            self.dealer_turn()
        self.show_result()

    def deal_initial_cards(self):
        for _ in range(2):
            self.player_hand.add_card(self.deck.deal_card())
            self.dealer_hand.add_card(self.deck.deal_card())

    def player_turn(self):
        while True:
            self.player_hand.display(self.player_name)
            print("Dealer's cards:")
            print(f"  {self.dealer_hand.cards[0]}")
            print("  <hidden card>\n")
            value = self.player_hand.calculate_value()
            print(f"{self.player_name}'s score: {value}")

            if value > 21:
                print("You busted! Dealer wins.\n")
                self.dealer_hand.display("Dealer")
                print(f"Dealer's score: {self.dealer_hand.calculate_value()}")
                return

            choice = input("Choose: (H)it, (S)tand or (R)eshuffle: ").strip().lower()
            if choice == 'h':
                self.player_hand.add_card(self.deck.deal_card())
            elif choice == 's':
                break
            elif choice == 'r':
                self.reshuffle_deck()
            else:
                print("Invalid choice, try again.")

    def dealer_turn(self):
        while self.dealer_hand.calculate_value() < 17:
            self.dealer_hand.add_card(self.deck.deal_card())
        self.dealer_hand.display("Dealer")
        print(f"Dealer's score: {self.dealer_hand.calculate_value()}")

    def reshuffle_deck(self):
        print("Reshuffling deck...\n")
        used_cards = self.player_hand.cards + self.dealer_hand.cards
        self.deck = Deck()
        for card in used_cards:
            if card in self.deck.cards:
                self.deck.cards.remove(card)

    def show_result(self):
        player_value = self.player_hand.calculate_value()
        dealer_value = self.dealer_hand.calculate_value()

        if player_value > 21:
            return
        if dealer_value > 21 or player_value > dealer_value:
            print(f"{self.player_name} wins!\n")
        elif player_value < dealer_value:
            print("Dealer wins!\n")
        else:
            print("It's a tie!\n")
